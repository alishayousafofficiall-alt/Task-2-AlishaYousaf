const express = require("express");
const cors = require("cors");

const app = express();
const PORT = 3000;

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// ─── In-Memory Data Store (no DB required) ────────────────────────────────────
let users = [
  { id: 1, name: "Alisha Yousaf", email: "alisha@example.com", role: "admin" },
  { id: 2, name: "Sara Khan",     email: "sara@example.com",   role: "user"  },
];
let nextId = 3;

// ─── Utility: Validators ─────────────────────────────────────────────────────
function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function isValidName(name) {
  return typeof name === "string" && name.trim().length >= 2;
}

// ─── ROOT ─────────────────────────────────────────────────────────────────────
app.get("/", (req, res) => {
  res.status(200).json({
    status: "success",
    message: "DecodeLabs Project 2 — Backend API is running 🚀",
    endpoints: {
      "GET  /users":        "Fetch all users",
      "GET  /users/:id":    "Fetch single user by ID",
      "POST /users":        "Create a new user",
      "GET  /users/search": "Search users by name or role (query: ?name=&role=)",
    },
  });
});

// ─── GET /users ───────────────────────────────────────────────────────────────
// Returns all users
app.get("/users", (req, res) => {
  res.status(200).json({
    status: "success",
    count: users.length,
    data: users,
  });
});

// ─── GET /users/search ────────────────────────────────────────────────────────
// Query: ?name=sara  OR  ?role=admin
app.get("/users/search", (req, res) => {
  const { name, role } = req.query;

  if (!name && !role) {
    return res.status(400).json({
      status: "error",
      message: "Provide at least one query param: name or role",
    });
  }

  let results = [...users];

  if (name) {
    results = results.filter((u) =>
      u.name.toLowerCase().includes(name.toLowerCase())
    );
  }
  if (role) {
    results = results.filter(
      (u) => u.role.toLowerCase() === role.toLowerCase()
    );
  }

  if (results.length === 0) {
    return res.status(404).json({
      status: "error",
      message: "No users found matching your criteria",
    });
  }

  res.status(200).json({
    status: "success",
    count: results.length,
    data: results,
  });
});

// ─── GET /users/:id ───────────────────────────────────────────────────────────
app.get("/users/:id", (req, res) => {
  const id = parseInt(req.params.id);

  if (isNaN(id)) {
    return res.status(400).json({
      status: "error",
      message: "ID must be a valid number",
    });
  }

  const user = users.find((u) => u.id === id);

  if (!user) {
    return res.status(404).json({
      status: "error",
      message: `User with id ${id} not found`,
    });
  }

  res.status(200).json({
    status: "success",
    data: user,
  });
});

// ─── POST /users ──────────────────────────────────────────────────────────────
// Body: { name, email, role? }
app.post("/users", (req, res) => {
  const { name, email, role } = req.body;

  // ── Syntactic Validation (format check) ──────────────────────
  const errors = [];

  if (!name)              errors.push("name is required");
  else if (!isValidName(name)) errors.push("name must be at least 2 characters");

  if (!email)             errors.push("email is required");
  else if (!isValidEmail(email)) errors.push("email format is invalid");

  if (errors.length > 0) {
    return res.status(400).json({
      status: "error",
      message: "Validation failed",
      errors,
    });
  }

  // ── Semantic Validation (logic check) ────────────────────────
  const duplicate = users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase()
  );
  if (duplicate) {
    return res.status(409).json({
      status: "error",
      message: "A user with this email already exists",
    });
  }

  const validRoles = ["admin", "user", "moderator"];
  const assignedRole = role && validRoles.includes(role.toLowerCase())
    ? role.toLowerCase()
    : "user";

  const newUser = {
    id: nextId++,
    name: name.trim(),
    email: email.toLowerCase().trim(),
    role: assignedRole,
  };

  users.push(newUser);

  res.status(201).json({
    status: "success",
    message: "User created successfully",
    data: newUser,
  });
});

// ─── 404 Handler (unknown routes) ────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({
    status: "error",
    message: `Route ${req.method} ${req.path} not found`,
  });
});

// ─── Global Error Handler ─────────────────────────────────────────────────────
app.use((err, req, res, next) => {
  console.error("Unhandled error:", err);
  res.status(500).json({
    status: "error",
    message: "Internal Server Error",
  });
});

// ─── Start Server ─────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`\n🚀 DecodeLabs P2 API running at http://localhost:${PORT}`);
  console.log(`📋 Endpoints:`);
  console.log(`   GET  http://localhost:${PORT}/users`);
  console.log(`   GET  http://localhost:${PORT}/users/:id`);
  console.log(`   GET  http://localhost:${PORT}/users/search?name=&role=`);
  console.log(`   POST http://localhost:${PORT}/users\n`);
});
